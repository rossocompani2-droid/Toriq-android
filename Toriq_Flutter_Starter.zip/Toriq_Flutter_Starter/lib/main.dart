import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

const gold = Color(0xFFE5C579);
const bg = Color(0xFF0B0C0A);
const panel = Color(0xFF171914);
const muted = Color(0xFFAAA38F);

void main() => runApp(const ToriqApp());

class ToriqApp extends StatelessWidget {
  const ToriqApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Toriq',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: gold, secondary: gold, surface: panel),
      useMaterial3: true,
      cardTheme: CardThemeData(
        color: Colors.white.withOpacity(.045),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: BorderSide(color: gold.withOpacity(.20)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: gold.withOpacity(.22))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: gold.withOpacity(.22))),
      ),
    ),
    home: const ToriqHome(),
  );
}

class ToriqHome extends StatefulWidget {
  const ToriqHome({super.key});
  @override
  State<ToriqHome> createState() => _ToriqHomeState();
}

class _ToriqHomeState extends State<ToriqHome> {
  int tab = 0, count = 0;
  String city = 'Toshkent, O‘zbekiston';
  late final TextEditingController _cityController = TextEditingController(text: city);
  String madhhab = 'Hanafiy';
  bool reminders = true;
  String status = 'Namoz vaqtlari internetdan olinadi';
  double? heading;
  double latitude = 41.2995, longitude = 69.2401;
  bool loadingPrayerTimes = false;
  String prayerDate = '';
  String prayerMethodNote = 'Hisoblash: Muslim World League (tekshirish tavsiya etiladi)';
  Map<String, String> prayerTimes = {'Fajr':'—','Sunrise':'—','Dhuhr':'—','Asr':'—','Maghrib':'—','Isha':'—'};

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _fetchPrayerTimes();
    FlutterCompass.events?.listen((event) {
      if (mounted) setState(() => heading = event.heading);
    });
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      city = p.getString('city') ?? city;
      _cityController.text = city;
      madhhab = p.getString('madhhab') ?? madhhab;
      reminders = p.getBool('reminders') ?? true;
      count = p.getInt('zikrCount') ?? 0;
      latitude = p.getDouble('latitude') ?? latitude;
      longitude = p.getDouble('longitude') ?? longitude;
    });
    _fetchPrayerTimes();
  }

  Future<void> _save(String key, Object value) async {
    final p = await SharedPreferences.getInstance();
    if (value is String) await p.setString(key, value);
    if (value is bool) await p.setBool(key, value);
    if (value is int) await p.setInt(key, value);
  }

  Future<void> _locate() async {
    try {
      var enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        setState(() => status = 'GPS o‘chiq. Telefon sozlamalarida GPSni yoqing.');
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() => status = 'Joylashuv ruxsati berilmadi. Shaharni qo‘lda tanlang.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      latitude = pos.latitude; longitude = pos.longitude;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('latitude', latitude); await prefs.setDouble('longitude', longitude);
      setState(() => status = 'GPS joylashuvi aniqlandi: ${latitude.toStringAsFixed(4)}, ${longitude.toStringAsFixed(4)}');
      await _fetchPrayerTimes();
    } catch (_) {
      setState(() => status = 'Joylashuvni olishda xatolik. Shaharni qo‘lda kiriting.');
    }
  }


  Future<void> _fetchPrayerTimes() async {
    if (mounted) setState(() => loadingPrayerTimes = true);
    try {
      final date = DateFormat('dd-MM-yyyy').format(DateTime.now());
      final school = madhhab == 'Hanafiy' ? '1' : '0';
      final uri = Uri.https('api.aladhan.com', '/v1/timings/$date', {
        'latitude': latitude.toString(), 'longitude': longitude.toString(),
        'method': '3', 'school': school,
      });
      final response = await http.get(uri).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) throw Exception('Namoz xizmati javob bermadi');
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      if (body['code'] != 200) throw Exception('Namoz vaqti hisoblanmadi');
      final timings = body['data']['timings'] as Map<String, dynamic>;
      String clean(String key) => (timings[key] ?? '--:--').toString().split(' ').first;
      if (!mounted) return;
      setState(() {
        prayerTimes = {'Fajr':clean('Fajr'),'Sunrise':clean('Sunrise'),'Dhuhr':clean('Dhuhr'),
          'Asr':clean('Asr'),'Maghrib':clean('Maghrib'),'Isha':clean('Isha')};
        prayerDate = body['data']['date']['readable']?.toString() ?? date;
        status = 'Namoz vaqtlari internet orqali hisoblandi. Mahalliy rasmiy taqvim bilan solishtiring.';
      });
    } catch (_) {
      if (mounted) setState(() => status = 'Namoz vaqtlarini yuklab bo‘lmadi. Internetni tekshirib, qayta urinib ko‘ring.');
    } finally {
      if (mounted) setState(() => loadingPrayerTimes = false);
    }
  }

  void _vibrate() => HapticFeedback.selectionClick();

  @override
  void dispose() {
    _cityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(), _qibla(), _zikr(), _assistant(), _settings()
    ];
    return Scaffold(
      body: SafeArea(child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 220),
        child: KeyedSubtree(key: ValueKey(tab), child: pages[tab]),
      )),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF171914),
        indicatorColor: gold.withOpacity(.12),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Bosh sahifa'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Qibla'),
          NavigationDestination(icon: Icon(Icons.fingerprint), selectedIcon: Icon(Icons.fingerprint), label: 'Tasbeh'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Toriq AI'),
          NavigationDestination(icon: Icon(Icons.tune), selectedIcon: Icon(Icons.tune), label: 'Sozlama'),
        ],
      ),
    );
  }

  Widget _page(String title, List<Widget> children) => ListView(
    key: ValueKey(title), padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
    children: [
      Row(children: [
        Container(width: 44, height: 44,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            gradient: const LinearGradient(colors: [Color(0xFFF3DEA0), Color(0xFF98702B)])),
          child: const Icon(Icons.nightlight_round, color: Color(0xFF171309), size: 26)),
        const SizedBox(width: 11),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Toriq', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, letterSpacing: -1)),
          Text('IBODATDA XOTIRJAMLIK', style: TextStyle(fontSize: 9, letterSpacing: 1.4, color: muted)),
        ]),
        const Spacer(),
        IconButton(onPressed: () => setState(() => tab = 4),
          icon: const Icon(Icons.settings_outlined, color: gold)),
      ]),
      const SizedBox(height: 18),
      ...children,
    ],
  );

  Widget _glass({required Widget child, EdgeInsets padding = const EdgeInsets.all(17)}) =>
    Card(child: Padding(padding: padding, child: child));

  Widget _heading(String title, {String trailing = ''}) => Padding(
    padding: const EdgeInsets.fromLTRB(3, 22, 3, 10),
    child: Row(children: [
      Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
      Text(trailing, style: const TextStyle(color: muted, fontSize: 10)),
    ]),
  );

  Widget _home() => _page('home', [
    _glass(child: Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF42351C), Color(0xFF171A14)])),
      padding: const EdgeInsets.all(3),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('ASSALOMU ALAYKUM 🤍', style: TextStyle(color: gold, fontSize: 10, letterSpacing: 1.3)),
        const SizedBox(height: 10),
        const Text('Har bir kuningizni ibodat bilan bezang',
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, height: 1.2)),
        const SizedBox(height: 8),
        Text(city, style: const TextStyle(color: muted)),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: Colors.black.withOpacity(.25), borderRadius: BorderRadius.circular(16)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(loadingPrayerTimes ? 'NAMOZ VAQTLARI YUKLANMOQDA' : 'BUGUNGI NAMOZ VAQTLARI', style: const TextStyle(color: muted, fontSize: 10, letterSpacing: 1)),
            const SizedBox(height: 5),
            Row(children: [
              const Expanded(child: Text('Peshin', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
              Text(prayerTimes['Dhuhr'] ?? '--:--', style: const TextStyle(color: gold, fontSize: 21, fontWeight: FontWeight.bold)),
            ]),
            Text(prayerDate.isEmpty ? prayerMethodNote : '$prayerDate · $prayerMethodNote', style: const TextStyle(color: muted, fontSize: 10)),
          ]),
        ),
      ]),
    )),
    _heading('Namoz vaqtlari', trailing: loadingPrayerTimes ? 'YUKLANMOQDA' : 'BUGUN'),
    _glass(child: Column(children: [
      PrayerRow('🌄', 'Bomdod', prayerTimes['Fajr'] ?? '--:--'),
      PrayerRow('☀️', 'Quyosh chiqishi', prayerTimes['Sunrise'] ?? '--:--'),
      PrayerRow('🌤️', 'Peshin', prayerTimes['Dhuhr'] ?? '--:--'),
      PrayerRow('🌥️', 'Asr', prayerTimes['Asr'] ?? '--:--'),
      PrayerRow('🌇', 'Shom', prayerTimes['Maghrib'] ?? '--:--'),
      PrayerRow('🌙', 'Xufton', prayerTimes['Isha'] ?? '--:--'),
      Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: _fetchPrayerTimes,
        icon: const Icon(Icons.refresh, size: 17), label: const Text('Vaqtlarni yangilash'))),
    ]), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5)),
    _heading('Ibodat vositalari'),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.35,
      children: [
        _tile(Icons.explore_outlined, 'Qibla', 'Kompas', 1),
        _tile(Icons.fingerprint, 'Tasbeh', 'Vibratsiyali zikr', 2),
        _tile(Icons.menu_book_outlined, 'Qur’on', 'O‘qish va tarjima', 3),
        _tile(Icons.auto_awesome, 'Toriq AI', 'Islomiy bilim', 3),
      ]),
    const SizedBox(height: 12),
    Text(status, style: const TextStyle(color: muted, fontSize: 11)),
  ]);

  Widget _tile(IconData icon, String title, String desc, int destination) => InkWell(
    borderRadius: BorderRadius.circular(20),
    onTap: () => setState(() => tab = destination),
    child: Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: gold, size: 25), const SizedBox(height: 8),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(desc, style: const TextStyle(color: muted, fontSize: 11)),
      ]))),
  );

  Widget _qibla() => _page('qibla', [
    _glass(child: Column(children: [
      const Text('QIBLA KOMPASSI', style: TextStyle(color: gold, letterSpacing: 1.3, fontSize: 11)),
      const SizedBox(height: 24),
      StreamBuilder<CompassEvent?>(
        stream: FlutterCompass.events,
        builder: (context, snapshot) {
          final heading = snapshot.data?.heading;
          if (heading == null) {
            return const Icon(Icons.explore_outlined, size: 135, color: gold);
          }
          return Transform.rotate(
            angle: -heading * (math.pi / 180),
            child: const Icon(Icons.navigation_rounded, size: 135, color: gold),
          );
        },
      ),
      const SizedBox(height: 14),
      const Text('Telefon kompas sensori', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Bu bosqichda shimol yo‘nalishi sensordan olinadi. Ka’ba tomonining haqiqiy burchagini ko‘rsatish uchun GPS koordinatalari bilan Qibla hisobini ulash zarur.',
        textAlign: TextAlign.center, style: TextStyle(color: muted, height: 1.5, fontSize: 12)),
      const SizedBox(height: 16),
      FilledButton.icon(onPressed: _locate, icon: const Icon(Icons.my_location),
        label: const Text('Joylashuvni aniqlash')),
      const SizedBox(height: 10),
      Text(status, style: const TextStyle(color: muted, fontSize: 11)),
    ])),
  ]);

  Widget _zikr() => _page('zikr', [
    _glass(child: Column(children: [
      const Text('TASBEH', style: TextStyle(color: gold, letterSpacing: 1.5, fontSize: 11)),
      const SizedBox(height: 18),
      const Text('سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
        textAlign: TextAlign.center, style: TextStyle(fontFamily: 'serif', fontSize: 29, height: 1.9)),
      const SizedBox(height: 5),
      const Text('Subhanallohi va bihamdih', style: TextStyle(fontSize: 15)),
      const Text('Allohni hamd bilan poklab yod etaman', style: TextStyle(color: muted, fontSize: 12)),
      const SizedBox(height: 20),
      Text('$count', style: const TextStyle(fontSize: 62, color: gold, fontWeight: FontWeight.w800)),
      const Text('Har bosishda haptik tebranish', style: TextStyle(color: muted, fontSize: 11)),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, height: 58, child: FilledButton(
        onPressed: () { _vibrate(); setState(() => count++); _save('zikrCount', count); },
        child: const Text('+1 Zikr', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)))),
      const SizedBox(height: 10),
      OutlinedButton(onPressed: () { _vibrate(); setState(() => count = 0); _save('zikrCount', 0); },
        child: const Text('Hisobni qayta boshlash')),
    ])),
  ]);

  Widget _assistant() => _page('assistant', [
    _glass(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.auto_awesome, color: gold, size: 30),
      const SizedBox(height: 8),
      const Text('Toriq AI', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      const Text('Islomiy bilim yordamchisi', style: TextStyle(color: muted)),
      const SizedBox(height: 14),
      const Text('Bu boshlang‘ich loyiha. Haqiqiy AI javoblari uchun server tomondagi AI API va manba tekshirish tizimi kerak. API kalitlarini mobil ilova ichiga yozmang.',
        style: TextStyle(height: 1.55)),
      const SizedBox(height: 14),
      const Text('Tavsiya etiladigan savollar', style: TextStyle(color: gold, fontWeight: FontWeight.bold)),
      const SizedBox(height: 7),
      const Text('• Tahoratning farzlari nimalar?\n• Hanafiy va Shofe’iy Asr vaqti qanday farq qiladi?\n• Safarda namoz qanday o‘qiladi?'),
    ])),
  ]);

  Widget _settings() => _page('settings', [
    _glass(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Joylashuv', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: _locate, icon: const Icon(Icons.my_location),
        label: const Text('GPS orqali aniqlash')),
      const SizedBox(height: 10),
      TextField(controller: _cityController,
        decoration: const InputDecoration(labelText: 'Shahar nomi (ma’lumot uchun)'),
        onChanged: (v) { city = v; _save('city', v); }),
      const SizedBox(height: 18),
      const Text('Mazhab', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      DropdownButtonFormField<String>(
        value: madhhab, decoration: const InputDecoration(),
        items: const [DropdownMenuItem(value: 'Hanafiy', child: Text('Hanafiy')),
          DropdownMenuItem(value: 'Shofe’iy', child: Text('Shofe’iy'))],
        onChanged: (v) { if (v != null) { setState(() => madhhab = v); _save('madhhab', v); _fetchPrayerTimes(); } }),
      const SizedBox(height: 18),
      const Text('Tanbeh', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      SwitchListTile(
        contentPadding: EdgeInsets.zero, value: reminders, activeColor: gold,
        title: const Text('Namozdan 10 daqiqa oldin'),
        subtitle: const Text('Bildirishnomalar moduli hali ulanmagan', style: TextStyle(color: muted, fontSize: 11)),
        onChanged: (v) { setState(() => reminders = v); _save('reminders', v); }),
      const Divider(color: Color(0x334E432B)),
      const Text('Google orqali kirish', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Google OAuth Client ID va Firebase yoki boshqa autentifikatsiya konfiguratsiyasi kerak.',
        style: TextStyle(color: muted, fontSize: 12, height: 1.5)),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Google sign-in hali konfiguratsiya qilinmagan.'))),
        icon: const Icon(Icons.login), label: const Text('Google orqali kirish · sozlash kerak')),
      const SizedBox(height: 10),
      Text(status, style: const TextStyle(color: muted, fontSize: 11)),
    ])),
  ]);
}

class PrayerRow extends StatelessWidget {
  final String emoji, name, time;
  const PrayerRow(this.emoji, this.name, this.time, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 11),
    child: Row(children: [
      Text(emoji, style: const TextStyle(fontSize: 18)),
      const SizedBox(width: 10),
      Expanded(child: Text(name)),
      Text(time, style: const TextStyle(color: gold, fontWeight: FontWeight.w700)),
    ]),
  );
}
