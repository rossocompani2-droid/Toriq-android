# Toriq — Flutter source starter

This archive contains the **Flutter source code**, not an already-built APK/IPA. The current work environment does not have Flutter/Android SDK or Apple's Xcode, so binaries could not be compiled or device-tested here.

## What is in this build
- Dark black-and-gold Flutter UI.
- Daily prayer-time retrieval from AlAdhan API using saved coordinates and madhhab setting.
- GPS permission flow and saved coordinates.
- Saved tasbih count with haptic feedback.
- Compass sensor reading (the Qibla bearing calculation is not yet implemented).
- Settings screen for city label, madhhab, and reminder toggle.

## Important limitations
- Prayer time currently uses AlAdhan method `3` (Muslim World League). This is **not guaranteed to match the official Uzbekistan timetable**. Verify against the local mosque/official religious authority before relying on it.
- Notifications 10 minutes before prayer are not implemented yet; the switch currently saves the preference only.
- Google sign-in, AI backend, actual Qibla bearing, and full Qur'an content are not connected.
- The app needs internet to fetch prayer times.
- No Android APK or signed iOS IPA is included in this archive.

## Build Android APK on a computer
1. Install Flutter stable and Android Studio/Android SDK.
2. Extract this archive.
3. In the `Toriq_Flutter_Starter` folder run:
   ```bash
   flutter create --platforms=android,ios .
   flutter pub get
   flutter build apk --release
   ```
4. APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Automated Android build with GitHub Actions
The archive includes `.github/workflows/android-apk.yml`. Upload the source folder to a GitHub repository, then open **Actions → Build Toriq Android APK → Run workflow**. When the workflow succeeds, download the `toriq-android-apk` artifact from that run. This requires the user to create/use a GitHub repository; it does not create a public download URL automatically from this chat.

## iOS
A real iPhone installable build requires macOS with Xcode. A signed IPA also requires Apple signing credentials and typically an Apple Developer account; TestFlight/App Store distribution requires Apple's process. This environment has no Xcode or Apple signing credentials, so an install-ready IPA cannot be produced here. Once on a Mac with Xcode, generate the iOS platform folder with `flutter create --platforms=android,ios .`, then configure signing in Xcode.

## Validation
The source was reviewed and obvious UI compilation issues were corrected, but it has **not** been run through `flutter analyze`, built, or tested on a physical phone in this environment.
